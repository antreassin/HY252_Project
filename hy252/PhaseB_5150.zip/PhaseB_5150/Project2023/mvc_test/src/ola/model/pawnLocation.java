package ola.model;

public enum pawnLocation {
    home, regular, safe,start
}
