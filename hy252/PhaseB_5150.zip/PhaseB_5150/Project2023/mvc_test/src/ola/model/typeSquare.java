package ola.model;

public enum typeSquare {
    slide, safeZone, home, start, normal
}
