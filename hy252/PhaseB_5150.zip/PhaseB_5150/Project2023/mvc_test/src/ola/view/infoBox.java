package ola.view;

import ola.model.card.deck;
import ola.model.player;

import javax.swing.*;

public class infoBox {
    /**
     * Prep for Gui, infoBox
     */
    private JTextArea textArea;
    public void setTextArea(deck Deck, player Player){

    }
}
