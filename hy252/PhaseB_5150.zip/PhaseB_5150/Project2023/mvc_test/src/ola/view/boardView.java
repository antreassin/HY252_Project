package ola.view;

import javax.swing.*;

public class boardView {
    /**
     * Prep for Gui, BoardView
     */
    JLabel text;
    JLabel[][] arr = new JLabel[16][16];
    boardView(){

    }
}
