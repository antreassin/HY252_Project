package ola.view;

import ola.model.card.deck;

import javax.swing.*;

public class deckView {
    /**
     * Prep for Gui, deckView
     */
    private JLabel text;
    private JButton foldB;
    public void setDeckView(deck Deck){

    }
}
