package ola.controller;

public class gameSet {
    private dataBase dataB;
    public static void newGame(){

    }
    public static void loadGame(){

    }
    static public dataBase getDataBase(){
        return null;
    }
}
